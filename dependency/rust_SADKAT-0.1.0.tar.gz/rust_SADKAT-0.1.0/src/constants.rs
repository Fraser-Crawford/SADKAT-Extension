pub const K: f64 = 1.380649e-23;
pub const GAS_CONSTANT: f64 = 8.314;
pub const SIGMA:f64 = 5.670374419e-8;